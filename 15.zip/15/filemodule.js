const fs = require('fs');

fs.writeFileSync("write.txt","this is first fs file write");

fs.appendFileSync("write.txt", "  And this file will append :");
