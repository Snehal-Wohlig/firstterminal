// console.log('Hello World')

const exp = require("constants");
const { required } = require("nodemon/lib/config");


// // Importing the module
// const readline = require("readline-sync");

// // Enter the number
// let a = Number(readline.question('Enter the Number? '));
// let number = [];
// for (let i = 0; i < a; ++i)
// {
// number.push(Number(readline.question()));
// }
// console.log(number);

// const readline = require('readline').createInterface({

//     input: process.stdin,
    
//     output: process.stdout
    
//     });
    
//     readline.question('Who are you?', name => {
    
//     console.log(`Hey there ${name}!`);
    
//     readline.close();
    
//     });


//  import * as readline from 'node:readline/promises';
//  import { stdin as input, stdout as output } from 'node:process';

//  const rl = readline.createInterface({ input, output });

//  const answer = await rl.question('What do you think of Node.js? ');

//  console.log(`Thank you for your valuable feedback: ${answer}`);

//  rl.close();

var r= require('readline');
var prompts= r.createInterface(process.stdin,process.stdout);
prompts.question("Number of years you've been working in corporate?",function(experience){
    var msg="";
    if(experience<5)
     msg="you're short of "+(5-experience) + "years experience to attend job interview at company!";
    else
    msg="Excellent,you're eligible for the job interview!";
    console.log(msg);
    process.exit();
});

