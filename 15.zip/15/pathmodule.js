const path = require('path');

const a= path.basename('/foo/bar/baz/asdf/quux.html');
console.log(a)